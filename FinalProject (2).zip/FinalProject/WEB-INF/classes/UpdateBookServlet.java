import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class UpdateBookServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        Book b = new Book(title, author, quantity);
        BookDao bdao = new BookDao();
        boolean f = bdao.UpdateBook(b);

        HttpSession session = request.getSession(true);
        if (f) {
            session.setAttribute("upd", "Book Updated");
            response.sendRedirect("admin.jsp");
        } else {
            session.setAttribute("nupd", "Book Not Found");
            response.sendRedirect("admin.jsp");
        }

    }
}
