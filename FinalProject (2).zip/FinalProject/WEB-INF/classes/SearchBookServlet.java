import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;

public class SearchBookServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String title = request.getParameter("title");

        // String author = request.getParameter("author");
        // int quantity = Integer.parseInt(request.getParameter("quantity"));

        // Book b = new Book(title, author, quantity);
        // Book b = new Book(title);
        BookDao bdao = new BookDao();
        Book book = bdao.SearchBook(title);

        if (book != null) {

            out.println("</br><table border=2px solid black>");
            out.println("<thead>");
            out.println("<tr>");
            out.println("<th><b> BookId </b></th>");
            out.println("<th><b> Book Name </b></th>");
            out.println("<th><b> Author </b></th>");
            out.println("<th><b> Quantity </b></th>");
            out.println("</tr>");
            out.println("</thead>");
            out.println("<tbody>");
            out.println("<tr>");
            out.println("<td >" + book.getId() + "</td>");
            out.println("<td >" + book.getTitle() + "</td>");
            out.println("<td >" + book.getAuthor() + "</td>");
            out.println("<td >" + book.getQuantity() + "</td>");
            out.println("</tr>");
            out.println("</tbody>");
            out.println("</table>");

        } else {
            out.println("no Book Found");
        }
        // HttpSession session = request.getSession(true);
        // if (f) {
        // response.sendRedirect("SearchBook.jsp");
        // } else {
        // session.setAttribute("fail", "Book Not Found");
        // response.sendRedirect("AddBook.jsp");
        // }

    }
}
