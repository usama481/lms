import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class DeleteBookServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String title = request.getParameter("title");
        Book b = new Book(title);
        BookDao bdao = new BookDao();
        boolean f = bdao.DeleteBook(b);

        HttpSession session = request.getSession(true);
        if (f) {
            session.setAttribute("Delete", "Book Deleted");
            response.sendRedirect("admin.jsp");
            // request.getRequestDispatcher("admin.jsp").forward(request, response);
        } else {
            session.setAttribute("fail", "Book Not Found");
            response.sendRedirect("admin.jsp");
            // request.getRequestDispatcher("admin.jsp").forward(request, response);
        }

    }
}
