import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class AddBookServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        Book b = new Book(title, author, quantity);

        BookDao bdao = new BookDao();
        boolean f = bdao.addBook(b);

        HttpSession session = request.getSession(true);
        if (f) {
            session.setAttribute("add", "Your Book Saved");
            response.sendRedirect("AddBook.jsp");
        } else {
            session.setAttribute("fail", "Sorry Failed..");
            response.sendRedirect("AddBook.jsp");
        }

    }
}
