import java.io.*;
import jakarta.servlet.http.*;
import jakarta.servlet.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;

public class ViewBooksServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Books</title></head><body>");
        BookDao bdao = new BookDao();
        ArrayList<Book> f = bdao.ViewBooks();

        for (Book b : f) { // loading data using loop from get row
            out.println("</br><table border=2px solid black>");
            out.println("<thead>");
            out.println("<tr>");
            out.println("<th><b> BookId </b></th>");
            out.println("<th><b> Book Name </b></th>");
            out.println("<th><b> Author </b></th>");
            out.println("<th><b> Quantity </b></th>");
            out.println("</tr>");
            out.println("</thead>");
            out.println("<tbody>");
            out.println("<tr>");
            out.println("<td >" + b.getId() + "</td>");
            out.println("<td >" + b.getTitle() + "</td>");
            out.println("<td >" + b.getAuthor() + "</td>");
            out.println("<td >" + b.getQuantity() + "</td>");
            out.println("</tr>");
            out.println("</tbody>");
            out.println("</table>");
            // HttpSession session = request.getSession();
            // session.setAttribute("title", title);
            // session.setAttribute("author", author);
            // session.setAttribute("quantity", quantity);
            // response.sendRedirect("");
        }
    }
}
