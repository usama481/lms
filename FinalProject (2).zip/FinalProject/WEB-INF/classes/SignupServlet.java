import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class SignupServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User u = new User(name, email, password, 0);

        UserDao udao = new UserDao();
        boolean f = udao.userSignup(u);

        // HttpSession session = request.getSession(true);
        // if (f) {
        // session.setAttribute("Success", "Signup Successful");
        // response.sendRedirect("Login.jsp");
        // }
    }
}
