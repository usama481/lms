import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.io.*;

public class BookDao {

    public boolean addBook(Book b) {
        boolean f = false;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String q = "insert into books(title,author,quantity) values (?,?,?)";
            PreparedStatement ps = con.prepareStatement(q);
            ps.setString(1, b.getTitle());
            ps.setString(2, b.getAuthor());
            ps.setInt(3, b.getQuantity());

            int i = ps.executeUpdate();

            if (i == 1) {
                f = true;
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return f;

    }

    public boolean issueBook(int id) {
        boolean f = false;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String q = "select * from books where id=?";
            PreparedStatement ps = con.prepareStatement(q);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();
            rs.next();
            int quantity = rs.getInt("quantity");
            if (quantity > 1) {
                q = "UPDATE books SET quantity=? WHERE id=?";
                ps = con.prepareStatement(q);
                ps.setInt(1, (quantity - 1));
                ps.setInt(2, id);
                ps.executeUpdate();
                f = true;
            }

            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return f;

    }

    public Book SearchBook(String t) {
        Book book = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String query = "SELECT * FROM books WHERE title = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, t);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String author = rs.getString("author");
                int quantity = rs.getInt("quantity");

                book = new Book(id, title, author, quantity);
            }
            con.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }

        return book;
    }// end method

    // public boolean SearchBook(Book b) {
    // boolean f = false;

    // try {
    // Class.forName("com.mysql.jdbc.Driver");
    // String url = "jdbc:mysql://127.0.0.1/lib_management";
    // Connection con = DriverManager.getConnection(url, "root", "root");

    // String query = "select * from books where title=?";
    // PreparedStatement ps = con.prepareStatement(query);
    // ps.setString(1, b.getTitle());
    // ResultSet rs = ps.executeQuery();

    // // rs.next();

    // // System.out.println("<h1>User Name: " + title + " </h1>");
    // // System.out.println("<h1>User Address: " + author + " </h1>");
    // // System.out.println("<h1>Quantity: " + quantity + " </h1>");
    // Book book = null;
    // if (rs.next()) {

    // int id = rs.getInt("id");
    // String title = rs.getString("title");
    // String author = rs.getString("author");
    // int quantity = rs.getInt("quantity");

    // book = new Book(id, title, author, quantity);
    // }
    // con.close();
    // f = true;
    // }

    // catch (ClassNotFoundException | SQLException ex) {
    // ex.printStackTrace();
    // }

    // return f;

    // }

    public boolean DeleteBook(Book b) {
        boolean f = false;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String query = "DELETE FROM books WHERE title = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, b.getTitle());
            int i = ps.executeUpdate();

            f = true;
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return f;

    }

    public boolean UpdateBook(Book b) {
        boolean f = false;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String query = "UPDATE books set quantity=? where title=? and author=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, b.getQuantity());
            ps.setString(2, b.getTitle());
            ps.setString(3, b.getAuthor());
            int i = ps.executeUpdate();

            f = true;
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return f;

    }

    public ArrayList<Book> ViewBooks() {
        ArrayList<Book> list = new ArrayList<Book>();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String q = "Select * from books";
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(q);

            while (rs.next()) {
                Book b = null;
                int id = rs.getInt(1);
                String name = rs.getString(2);
                String author = rs.getString(3);
                int quantity = rs.getInt(4);
                b = new Book(id, name, author, quantity);
                list.add(b);
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return list;

    }
}
