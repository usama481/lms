import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class DeleteStudentServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        User u = new User(name);
        UserDao udao = new UserDao();
        boolean f = udao.DeleteStudent(u);

        HttpSession session = request.getSession(true);
        if (f) {
            session.setAttribute("Deleted", "Student Deleted");
            response.sendRedirect("admin.jsp");
        } else {
            session.setAttribute("fails", "Student Not Found");
            response.sendRedirect("admin.jsp");
        }

    }
}
