import java.sql.*;

public class UserDao {

    public boolean userSignup(User u) {
        boolean f = false;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String q = "insert into signup(name,email, password, userType) values (?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(q);
            ps.setString(1, u.getName());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getPassword());
            ps.setInt(4, 0);
            int i = ps.executeUpdate();

            if (i == 1) {
                f = true;
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return f;

    }

    public User userLogin(String e, String p) {
        User user = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String q = "Select * from signup where email = ? and password =?";
            PreparedStatement ps = con.prepareStatement(q);
            ps.setString(1, e);
            ps.setString(2, p);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                user = new User();
                user.setuserType(rs.getInt("userType"));
                user.setName(rs.getString(1));
                user.setEmail(rs.getString(2));
                user.setPassword(rs.getString(3));

            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return user;

    }

    public boolean DeleteStudent(User u) {
        boolean f = false;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String query = "DELETE FROM signup WHERE name = ? and userType = 0";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, u.getName());
            int i = ps.executeUpdate();

            f = true;
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return f;

    }
}
